print("Starter project created. Bot logic still needs to be implemented.")
