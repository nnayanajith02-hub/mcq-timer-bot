MCQ Timer Bot

This is a starter project. You still need to add your bot token and bot logic.
